# KIBARATÃO — Next.js Starter

Projeto mínimo pronto para deploy na Vercel.

## O que já está configurado
- Logo: `public/logo.png`
- WhatsApp: https://chat.whatsapp.com/G2sIdKL2DUpHsGWbWt1BYo
- Amazon Affiliate tag: `onamzeverprom-20`
- Mercado Livre tracking page: https://www.mercadolivre.com.br/social/kibaratao
- Magazine Você link: https://www.magazinevoce.com.br/magazineevblackpromocoes/

## Como rodar localmente
1. `npm install`
2. `npm run dev`
3. Abra http://localhost:3000

## Deploy na Vercel
1. Suba este repositório ao GitHub.
2. No Vercel, crie um novo projeto conectando ao repositório.
3. Deploy automático e adicione domínio em **Settings > Domains**.

