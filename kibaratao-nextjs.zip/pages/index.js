import Head from 'next/head'

const WHATSAPP = "https://chat.whatsapp.com/G2sIdKL2DUpHsGWbWt1BYo"
const AMAZON_TAG = "onamzeverprom-20"
const ML_PAGE = "https://www.mercadolivre.com.br/social/kibaratao"
const MAGAZINE = "https://www.magazinevoce.com.br/magazineevblackpromocoes/"

const OFFERS = [
  {
    id: 'amz-ps5',
    title: 'PlayStation 5 Slim 1TB',
    image: 'https://images.unsplash.com/photo-1606813907291-76a3605b8b56?q=80&w=1200&auto=format&fit=crop',
    price: 3199.00,
    url: 'https://www.amazon.com.br/dp/B0BLTQFZ6Z?tag=' + AMAZON_TAG
  },
  {
    id: 'amz-echo',
    title: 'Echo Dot (5ª Geração)',
    image: 'https://images.unsplash.com/photo-1543512214-318c7553f230?q=80&w=1200&auto=format&fit=crop',
    price: 199.00,
    url: 'https://www.amazon.com.br/dp/B09B8V1GFK?tag=' + AMAZON_TAG
  },
]

export default function Home() {
  return (
    <>
      <Head>
        <title>KIBARATÃO — Promoções</title>
        <meta name="description" content="Kibaratao - promoções, cupons e ofertas em um só lugar" />
      </Head>
      <main>
        <div className="container">
          <header className="header">
            <div className="logo">
              <img src="/logo.png" alt="KIBARATÃO logo" />
              <div>
                <h1 style={{margin:0, fontSize:28, color:'#3f2710'}}>KIBARATÃO</h1>
                <div style={{color:'#6b4b1e'}}>Promoções selecionadas — sem custo</div>
              </div>
            </div>
            <div>
              <a className="btn" href={WHATSAPP} target="_blank" rel="noreferrer">Entrar no grupo</a>
            </div>
          </header>

          <section style={{marginTop:20}}>
            <div className="card">
              <h2 style={{margin:0}}>Ofertas do dia</h2>
              <div style={{marginTop:12}} className="grid">
                {OFFERS.map(o => (
                  <div key={o.id} className="offer card">
                    <img src={o.image} alt={o.title} />
                    <h3>{o.title}</h3>
                    <div className="price">R$ {o.price.toFixed(2)}</div>
                    <div style={{marginTop:8, display:'flex', gap:8}}>
                      <a className="btn" href={o.url} target="_blank" rel="noopener noreferrer">Ver na Amazon</a>
                      <a className="btn" href={ML_PAGE} target="_blank" rel="noopener noreferrer" style={{background:'#2563eb'}}>Mercado Livre</a>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <footer className="footer">
            <p>© {new Date().getFullYear()} KIBARATÃO — Todas as promoções em um só lugar.</p>
            <p style={{marginTop:8}}>Magazine Você: <a href={MAGAZINE} target="_blank" rel="noreferrer">promoções</a></p>
          </footer>
        </div>
      </main>
    </>
  )
}
